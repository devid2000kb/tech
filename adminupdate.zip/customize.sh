#!/system/bin/sh
[ "$ARCH" = "arm64" ] || abort "! AdminUpdate requires arm64"
ui_print "- AdminUpdate v4.1"
set_perm_recursive "$MODPATH" 0 0 0755 0644
for F in service.sh post-fs-data.sh uninstall.sh auto_hide.sh watch.sh devhide.sh auto_update.sh auto_pif.sh module_update.sh; do
  set_perm "$MODPATH/$F" 0 0 0755
done
mkdir -p /data/adb/adminupdate
echo "installed $(date)" > /data/adb/adminupdate/install.log
ui_print "- Reboot to activate"
