#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/pif.log
STAMP=$DATA/pif_stamp
TRIAL=$DATA/pif_trial
GOOD=$DATA/pif_good.prop
PIF=/data/adb/modules/playintegrityfix/custom.pif.prop
MOD=/data/adb/modules/playintegrityfix
CHECKER=gr.nikolasspyr.integritycheck
INTERVAL=2592000
PIDFILE=$DATA/auto_pif.pid
mkdir -p "$DATA"
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && exit 0
fi
echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
hide_checker() {
  am force-stop "$CHECKER" >/dev/null 2>&1
  pm hide "$CHECKER" >/dev/null 2>&1
}
validate() {
  pm unhide "$CHECKER" >/dev/null 2>&1
  input keyevent 224 >/dev/null 2>&1
  wm dismiss-keyguard >/dev/null 2>&1
  am force-stop "$CHECKER" >/dev/null 2>&1
  am start -W -n "$CHECKER/.MainActivity" >/dev/null 2>&1
  sleep 3
  uiautomator dump /sdcard/auto_pif_pre.xml >/dev/null 2>&1
  BTN=$(sed 's/></>\n</g' /sdcard/auto_pif_pre.xml 2>/dev/null | grep 'text="CHECK"' | head -1)
  B=$(echo "$BTN" | sed -n 's/.*bounds="\[\([0-9]*\),\([0-9]*\)\]\[\([0-9]*\),\([0-9]*\)\].*/\1 \2 \3 \4/p')
  [ -z "$B" ] && { hide_checker; return 1; }
  set -- $B
  input tap $(( ($1+$3)/2 )) $(( ($2+$4)/2 )) >/dev/null 2>&1
  sleep 18
  uiautomator dump /sdcard/auto_pif.xml >/dev/null 2>&1
  XML=$(sed 's/></>\n</g' /sdcard/auto_pif.xml 2>/dev/null)
  OK=1
  for K in basic device strong; do
    TAG=$(echo "$XML" | grep "resource-id=\"$CHECKER:id/${K}_integrity_icon\"" | head -1)
    echo "$TAG" | grep -q 'content-desc="Pass"' || OK=0
  done
  hide_checker
  rm -f /sdcard/auto_pif_pre.xml /sdcard/auto_pif.xml
  [ "$OK" = "1" ]
}
if [ "$1" = "--test" ]; then
  validate
  echo "VALID=$?"
  exit 0
fi
if [ -f "$TRIAL" ]; then
  if validate; then
    log "new PIF passed; keeping"
    cp -f "$PIF" "$GOOD"
    rm -f "$TRIAL"
  else
    log "new PIF failed; restoring backup"
    cp -f "$GOOD" "$PIF"
    rm -f "$TRIAL"
    sleep 5
    svc power reboot
    exit 0
  fi
  date +%s > "$STAMP"
fi
if [ ! -f "$GOOD" ] && [ -f "$PIF" ]; then
  cp -f "$PIF" "$GOOD"
fi
while true; do
  NOW=$(date +%s)
  LAST=$(cat "$STAMP" 2>/dev/null)
  [ -z "$LAST" ] && LAST=0
  if [ "$LAST" = "0" ]; then
    date +%s > "$STAMP"
    LAST=$NOW
  fi
  if [ $((NOW - LAST)) -ge "$INTERVAL" ]; then
    cp -f "$PIF" "$GOOD"
    if [ -f "$MOD/autopif4.sh" ]; then
      ( cd "$MOD" && sh autopif4.sh --strong ) >>"$LOG" 2>&1
    fi
    if [ -f "$PIF" ] && ! cmp -s "$PIF" "$GOOD"; then
      touch "$TRIAL"
      date +%s > "$STAMP"
      log "new PIF staged; rebooting for validation"
      cmd notification post -t "PIF rotation" system "Rebooting to test new PIF" >/dev/null 2>&1
      sleep 10
      svc power reboot
      exit 0
    fi
    date +%s > "$STAMP"
  fi
  sleep 3600
done
