#!/system/bin/sh
for F in /data/adb/adminupdate/*.pid; do
  [ -f "$F" ] && kill -9 $(cat "$F") 2>/dev/null
done
pkill -f "/data/adb/modules/adminupdate/watch.sh" 2>/dev/null
pkill -f "/data/adb/modules/adminupdate/devhide.sh" 2>/dev/null
rm -f /data/adb/service.d/adminupdate_auto_hide.sh
rm -rf /data/adb/hide_developer_options
