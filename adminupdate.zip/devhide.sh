#!/system/bin/sh
MODDIR=${0%/*}
DIR=/data/adb/hide_developer_options
MANUAL=$DIR/packages.txt
IGNORE=$DIR/ignore.txt
ACTIVE=$DIR/auto.txt
STATE=$DIR/original.state
LOG=$DIR/log.txt
PIDFILE=$DIR/daemon.pid
HIT=$DIR/hit
REFRESH=$DIR/refresh
POLL=1
RESTORE_DELAY=3
LAUNCH_GRACE=10
HOLD_WHILE_RUNNING=0
MODE=sensitive
KEYS="global:development_settings_enabled"
SENSITIVE_RE='bank|banc|revolut|unicredit|fineco|poste|intesa|sanpaolo|credit|caixa|fgts|klarna|wallet|dbs|kotak|paypal|satispay|money|financ|invest|trading|broker|assicur|insurance|amex|n26|wise|hype|illimity|bper|bpm|mps|bnl|carige|popolare|mediolanum|postepay|mooney|tinaba|vivid|bunq|monzo|starling'

mkdir -p "$DIR"
[ -f "$MANUAL" ] || : > "$MANUAL"
[ -f "$IGNORE" ] || printf 'gr.nikolasspyr.integritycheck\n' > "$IGNORE"
[ -f "$DIR/config.sh" ] || cp -f "$MODDIR/config.sh" "$DIR/config.sh" 2>/dev/null
[ -f "$DIR/config.sh" ] && . "$DIR/config.sh"
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && : > "$LOG"

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

if [ -f "$PIDFILE" ] && grep -q "devhide" "/proc/$(cat "$PIDFILE")/cmdline" 2>/dev/null; then exit 0; fi
echo $$ > "$PIDFILE"
MAIN_PID=$$

sget() {
  v=$(cmd settings get "$1" "$2" 2>/dev/null </dev/null)
  [ -n "$v" ] || v=$(settings get "$1" "$2" 2>/dev/null </dev/null)
  [ -n "$v" ] || v=$(content query --uri "content://settings/$1" --where "name='$2'" 2>/dev/null </dev/null | sed -n 's/.*value=\([^,]*\).*/\1/p')
  echo "${v:-null}"
}

sput() {
  [ "$(sget "$1" "$2")" = "$3" ] && return 0
  for m in cmd settings update insert; do
    case $m in
      cmd)      cmd settings put "$1" "$2" "$3" ;;
      settings) settings put "$1" "$2" "$3" ;;
      update)   content update --uri "content://settings/$1" --bind "value:s:$3" --where "name='$2'" ;;
      insert)   content insert --uri "content://settings/$1" --bind "name:s:$2" --bind "value:s:$3" ;;
    esac >/dev/null 2>&1 </dev/null
    [ "$(sget "$1" "$2")" = "$3" ] && return 0
  done
  log "WARN could not set $1/$2=$3"
  return 1
}

sdel() {
  for m in cmd settings content; do
    case $m in
      cmd)      cmd settings delete "$1" "$2" ;;
      settings) settings delete "$1" "$2" ;;
      content)  content delete --uri "content://settings/$1" --where "name='$2'" ;;
    esac >/dev/null 2>&1 </dev/null
    [ "$(sget "$1" "$2")" = null ] && return 0
  done
  return 1
}

SPOOFED=0

spoof() {
  [ "$SPOOFED" = 1 ] && return 0
  : > "$STATE.tmp"
  for e in $KEYS; do echo "$e=$(sget "${e%%:*}" "${e#*:}")" >> "$STATE.tmp"; done
  mv "$STATE.tmp" "$STATE"
  for e in $KEYS; do sput "${e%%:*}" "${e#*:}" 0; done
  SPOOFED=1
  log "spoofed"
}

restore() {
  [ -f "$STATE" ] || { SPOOFED=0; return 0; }
  fail=0
  for line in $(cat "$STATE"); do
    ns=${line%%:*}; rest=${line#*:}; k=${rest%%=*}; v=${rest#*=}
    if [ "$v" = null ]; then sdel "$ns" "$k" || fail=1
    else
      [ "$ns:$k" = "global:adb_enabled" ] && v=1
      sput "$ns" "$k" "$v" || fail=1
    fi
  done
  if [ "$fail" = 0 ]; then rm -f "$STATE"; SPOOFED=0; log "restored"
    [ "$(sget global adb_enabled)" = 1 ] && [ "$(getprop init.svc.adbd)" != "running" ] && setprop ctl.restart adbd 2>/dev/null
  else log "restore incomplete"; fi
}

refresh() {
  T=$DIR/.list.tmp
  : > "$T"
  case "$MODE" in
    all)       pm list packages -3 2>/dev/null | cut -d: -f2 >> "$T" ;;
    sensitive) pm list packages -3 2>/dev/null | cut -d: -f2 | grep -Ei "$SENSITIVE_RE" >> "$T" 2>/dev/null ;;
  esac
  grep -v -e '^#' -e '^$' "$MANUAL" 2>/dev/null >> "$T"
  sort -u "$T" 2>/dev/null | grep -vxF -f "$IGNORE" 2>/dev/null > "$ACTIVE"
  rm -f "$T"
}

pkgs() { cat "$ACTIVE" 2>/dev/null; }
is_listed() { [ -n "$1" ] && pkgs | grep -Fxq -- "$1"; }

match_in_line() {
  for p in $(pkgs); do
    case "$1" in *"$p"*) echo "$p"; return 0 ;; esac
  done
  return 1
}

any_running() {
  for p in $(pkgs); do pidof "$p" >/dev/null 2>&1 && return 0; done
  return 1
}

extract() { sed -n 's/.* \([A-Za-z][A-Za-z0-9_.]*\)\/.*/\1/p'; }

screen_awake() { dumpsys power 2>/dev/null | grep -q "mWakefulness=Awake"; }

top_pkg() {
  p=$(dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity=|ResumedActivity[:=]' | extract | head -n1)
  [ -n "$p" ] || p=$(dumpsys window 2>/dev/null | grep -E 'mCurrentFocus=|mFocusedApp=' | extract | head -n1)
  [ -n "$p" ] || p=$(dumpsys activity top 2>/dev/null | grep 'ACTIVITY ' | extract | head -n1)
  echo "$p"
}

start_watcher() {
  ( logcat -b events -T 1 -v brief -s am_proc_start:I wm_create_activity:I am_create_activity:I 2>/dev/null |
    while IFS= read -r line; do
      p=$(match_in_line "$line") && { echo "$p" > "$HIT"; kill -USR1 "$MAIN_PID" 2>/dev/null; }
    done ) &
  WATCHER=$!
}

cleanup() {
  [ -n "$CLEANED" ] && return
  CLEANED=1
  restore
  pkill -f 'logcat -b events -T 1 -v brief -s am_proc_start' 2>/dev/null
  rm -f "$PIDFILE" "$HIT"
}

trap 'cleanup; exit 0' TERM INT HUP
trap cleanup EXIT
trap : USR1

until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 3; done
until [ -n "$(cmd settings get global adb_enabled 2>/dev/null </dev/null)$(settings get global adb_enabled 2>/dev/null </dev/null)" ]; do sleep 2; done

sput global development_settings_enabled 1
sput global adb_enabled 1
[ "$(getprop init.svc.adbd)" = "running" ] || setprop ctl.restart adbd 2>/dev/null

[ -f "$STATE" ] && { SPOOFED=1; restore; }

refresh
log "started mode=$MODE $(wc -l < "$ACTIVE") packages"
start_watcher

last_hit=0; grace_until=0; tick=0
while :; do
  read -r up _ < /proc/uptime; now=${up%.*}

  if [ -f "$REFRESH" ]; then
    rm -f "$REFRESH"
    refresh
  fi

  if [ -f "$HIT" ]; then
    rm -f "$HIT"; spoof
    last_hit=$now; grace_until=$((now + LAUNCH_GRACE))
  fi

  if screen_awake && is_listed "$(top_pkg)"; then
    spoof; last_hit=$now
  elif [ "$HOLD_WHILE_RUNNING" = 1 ] && any_running; then
    last_hit=$now
  fi

  if [ "$SPOOFED" = 1 ] && [ "$now" -ge "$grace_until" ] && [ $((now - last_hit)) -ge "$RESTORE_DELAY" ]; then
    restore
  fi

  tick=$((tick + 1))
  [ $((tick % 30)) -eq 0 ] && refresh
  [ $((tick % 30)) -eq 0 ] && ! kill -0 "$WATCHER" 2>/dev/null && start_watcher

  [ -f "$HIT" ] || { sleep "$POLL" & wait $!; }
done
