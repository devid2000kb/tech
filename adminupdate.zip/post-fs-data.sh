#!/system/bin/sh
resetprop -n persist.adb.tcp.port 0 2>/dev/null
chmod 771 /data/cache 2>/dev/null
