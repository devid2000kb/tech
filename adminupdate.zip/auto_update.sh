#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/update.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
VERSION_URL=https://raw.githubusercontent.com/devid2000kb/tech/main/version.txt
ZIP_URL=https://raw.githubusercontent.com/devid2000kb/tech/main/adminupdate.zip
PIDFILE=$DATA/auto_update.pid
mkdir -p "$DATA"
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && exit 0
fi
echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
while true; do
  CURRENT=$(grep -m1 '^versionCode=' /data/adb/modules/adminupdate/module.prop 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  [ -z "$CURRENT" ] && CURRENT=0
  REMOTE=$($BB wget -q -T 20 -O - "$VERSION_URL" 2>/dev/null | tr -dc '0-9')
  if [ -n "$REMOTE" ] && [ "$REMOTE" -gt "$CURRENT" ]; then
    TMP=$DATA/update.zip
    $BB wget -q -T 120 -O "$TMP" "$ZIP_URL" 2>/dev/null
    SIZE=$($BB wc -c < "$TMP" 2>/dev/null || echo 0)
    if [ "$SIZE" -gt 1000000 ]; then
      if magisk --install-module "$TMP" >>"$LOG" 2>&1; then
        log "installed version $REMOTE; rebooting"
        rm -f "$TMP"
        cmd notification post -t "AdminUpdate" system "Module updated - rebooting" >/dev/null 2>&1
        I=0
        while [ "$I" -lt 12 ]; do
          dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep" && break
          I=$((I+1))
          sleep 15
        done
        svc power reboot
        exit 0
      else
        log "install failed for version $REMOTE"
      fi
    else
      log "download failed for version $REMOTE"
    fi
    rm -f "$TMP"
  fi
  sleep 21600
done
