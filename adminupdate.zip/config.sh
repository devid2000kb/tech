MODE=sensitive
SENSITIVE_RE='bank|banc|revolut|unicredit|fineco|poste|intesa|sanpaolo|credit|caixa|fgts|klarna|wallet|dbs|kotak|paypal|satispay|money|financ|invest|trading|broker|assicur|insurance|amex|n26|wise|hype|illimity|bper|bpm|mps|bnl|carige|popolare|mediolanum|postepay|mooney|tinaba|vivid|bunq|monzo|starling'
