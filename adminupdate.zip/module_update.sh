#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/modules.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASE=https://raw.githubusercontent.com/devid2000kb/tech/main
PIDFILE=$DATA/module_update.pid
mkdir -p "$DATA"
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && exit 0
fi
echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
while true; do
  TMP=$DATA/manifest.remote
  if ! $BB wget -q -T 20 -O "$TMP" "$BASE/manifest.txt" 2>/dev/null; then
    log "manifest download failed"
    rm -f "$TMP"
    sleep 1800
    continue
  fi
  CHANGED=0
  while IFS='|' read -r ID REMOTE FILE NAME; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
    [ -z "$CUR" ] && CUR=0
    if [ "$REMOTE" -gt "$CUR" ]; then
      ZIP=$DATA/module.zip
      if ! $BB wget -q -T 180 -O "$ZIP" "$BASE/$FILE" 2>/dev/null; then
        log "download failed $ID $REMOTE"
        rm -f "$ZIP"
        continue
      fi
      SIZE=$($BB wc -c < "$ZIP" 2>/dev/null || echo 0)
      if [ "$SIZE" -lt 100000 ]; then
        log "invalid $ID download"
        rm -f "$ZIP"
        continue
      fi
      if magisk --install-module "$ZIP" >>"$LOG" 2>&1; then
        log "installed $ID $REMOTE"
        CHANGED=1
      else
        log "install failed $ID $REMOTE"
      fi
      rm -f "$ZIP"
    fi
  done < "$TMP"
  rm -f "$TMP"
  if [ "$CHANGED" = "1" ]; then
    cmd notification post -t "AdminUpdate" system "Modules updated - rebooting" >/dev/null 2>&1
    I=0
    while [ "$I" -lt 12 ]; do
      dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep" && break
      I=$((I+1))
      sleep 15
    done
    svc power reboot
    exit 0
  fi
  sleep 21600
done
