#!/system/bin/sh
MODDIR=${0%/*}
DATA=/data/adb/adminupdate
LOG=$DATA/adminupdate.log
mkdir -p "$DATA"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
I=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$I" -lt 120 ]; do
  I=$((I+1))
  sleep 2
done
CHANGED=0
install_missing() {
  ID=$1
  ZIP=$2
  if [ -d "/data/adb/modules/$ID" ] || [ -d "/data/adb/modules_update/$ID" ]; then
    return 0
  fi
  log "installing $ID"
  if magisk --install-module "$MODDIR/payload/$ZIP" >>"$LOG" 2>&1; then
    CHANGED=1
  else
    log "install failed $ID"
  fi
}
install_missing zygisksu neozygisk.zip
install_missing tricky_store tricky_store.zip
install_missing playintegrityfix playintegrityfix.zip
if [ "$CHANGED" = "1" ]; then
  log "core modules staged"
  if [ ! -f "$DATA/reboot_pending" ]; then
    touch "$DATA/reboot_pending"
    sleep 10
    svc power reboot
  fi
  exit 0
fi
rm -f "$DATA/reboot_pending"
for ID in zygisksu tricky_store playintegrityfix; do
  rm -f "/data/adb/modules/$ID/disable"
done
for ID in zygisk_shamiko zygisk-assistant hosts teesim; do
  [ -d "/data/adb/modules/$ID" ] && touch "/data/adb/modules/$ID/disable"
done
cp -f "$MODDIR/payload/keybox.xml" /data/adb/tricky_store/keybox.xml
chmod 644 /data/adb/tricky_store/keybox.xml 2>/dev/null
rm -f "$DATA/keybox_updated"
if ! /system/bin/dumpsys package gr.nikolasspyr.integritycheck 2>/dev/null | grep -q 'codePath='; then
  SESSION=$(/system/bin/pm install-create -r -i com.android.vending --user 0 2>&1 | sed -n 's/.*\[\([0-9][0-9]*\)\].*/\1/p')
  if [ -n "$SESSION" ]; then
    sleep 2
    OK=1
    for APK in "$MODDIR"/payload/checker/*.apk; do
      SIZE=$(wc -c < "$APK")
      /system/bin/pm install-write -S "$SIZE" "$SESSION" "$(basename "$APK")" "$APK" >/dev/null 2>&1 || OK=0
    done
    if [ "$OK" = "1" ]; then
      /system/bin/pm install-commit "$SESSION" >/dev/null 2>&1
    else
      /system/bin/pm install-abandon "$SESSION" >/dev/null 2>&1
    fi
  fi
fi
if /system/bin/dumpsys package gr.nikolasspyr.integritycheck 2>/dev/null | grep -q 'codePath='; then
  /system/bin/pm hide gr.nikolasspyr.integritycheck >/dev/null 2>&1
  log "checker ready"
else
  log "checker install failed"
fi
magisk --sqlite "update settings set value=0 where key='zygisk'" >/dev/null 2>&1
magisk --sqlite "update settings set value=0 where key='denylist'" >/dev/null 2>&1
cp -f "$MODDIR/auto_hide.sh" /data/adb/service.d/adminupdate_auto_hide.sh
chmod 755 /data/adb/service.d/adminupdate_auto_hide.sh
sh "$MODDIR/auto_hide.sh" >/dev/null 2>&1
pkill -f "adminupdate/watch[.]sh" 2>/dev/null
pkill -f "adminupdate/pif[.]sh" 2>/dev/null
nohup sh "$MODDIR/watch.sh" >/dev/null 2>&1 &
nohup sh "$MODDIR/pif.sh" >/dev/null 2>&1 &
log "ready"
