import base64
import concurrent.futures
import datetime
import json
import os
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
PANEL = os.path.join(ROOT, "panel.html")
LIB = os.path.join(ROOT, "modules")
SCRIPTS = os.path.join(ROOT, "scripts")
BACKUPS = os.path.join(ROOT, "backups")
REPORTS = os.path.join(ROOT, "reports")
DATA_KEYBOX = os.path.join(ROOT, "data", "keybox", "keybox.xml")
DATA_PIF = os.path.join(ROOT, "data", "pif", "custom.pif.prop")
LAST_CHECK_FILE = os.path.join(REPORTS, "phone-check.json")
SCRCPY_BIN = os.path.join(ROOT, "tools", "scrcpy", "scrcpy")
SCRCPY_REC = "/tmp/opencode/admin-vdisplay.mkv"
SCRCPY_LOG = "/tmp/opencode/admin-vdisplay.log"
PORT = 8080
ADB = shutil.which("adb") or "adb"
KEYBOX_URL = "https://raw.githubusercontent.com/aaakkkpppm-bit/a/main/kb"
KEYBOX_SOURCES = (KEYBOX_URL,)

PHONE_LOCK = threading.Lock()
PHONE_STATE = {"last_check": None}
PHONE_LOCAL = threading.local()
DEVICE_CACHE = {}
DEVICE_CACHE_FILE = os.path.join(ROOT, "data", "devices.json")
BATCH_LOCK = threading.Lock()
BATCH_JOBS = {}


def set_target(serial):
    PHONE_LOCAL.serial = str(serial or "")


def target_serial():
    return getattr(PHONE_LOCAL, "serial", "")


def adb_run(args, timeout=30, binary=False):
    try:
        command = [ADB]
        serial = target_serial()
        if serial:
            command += ["-s", serial]
        command += args
        proc = subprocess.run(command, capture_output=True, timeout=timeout)
        if binary:
            return proc.returncode, proc.stdout, proc.stderr.decode("utf-8", "replace")
        return proc.returncode, proc.stdout.decode("utf-8", "replace"), proc.stderr.decode("utf-8", "replace")
    except Exception as exc:
        if binary:
            return 1, b"", str(exc)
        return 1, "", str(exc)


def adb_su(script, timeout=60):
    blob = base64.b64encode(script.encode("utf-8")).decode("ascii")
    cmd = "su -c 'echo %s | base64 -d | sh'" % blob
    return adb_run(["shell", cmd], timeout=timeout)


def adb_cat(path, timeout=20):
    code, data, err = adb_run(["exec-out", "su -c 'cat %s'" % path], timeout=timeout, binary=True)
    if code == 0:
        return data
    return b""


def adb_push(local, remote, timeout=90):
    return adb_run(["push", local, remote], timeout=timeout)


def write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    os.replace(tmp, path)


def load_last_check():
    try:
        with open(LAST_CHECK_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            PHONE_STATE["last_check"] = data
    except Exception:
        pass


def save_last_check(data):
    try:
        os.makedirs(REPORTS, exist_ok=True)
        with open(LAST_CHECK_FILE, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
    except Exception:
        pass


def split_sections(text):
    parts = re.split(r"(?m)^__([A-Z_]+)__\s*$", text)
    out = {}
    if len(parts) >= 3:
        for index in range(1, len(parts), 2):
            out[parts[index]] = parts[index + 1].strip("\r\n")
    return out


def kv_lines(text):
    out = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            out[key.strip()] = value.strip()
    return out


def decode_b64(text):
    try:
        clean = re.sub(r"\s+", "", text or "")
        return base64.b64decode(clean).decode("utf-8", "replace")
    except Exception:
        return ""


def keybox_info(text):
    if not text or "<" not in text:
        return {"present": False}
    certs = []
    try:
        from cryptography import x509
        blocks = re.findall(r"<Certificate\s+format=\"pem\">(.*?)</Certificate>", text, re.S)
        for block in blocks:
            pem = "\n".join(line.strip() for line in block.strip().splitlines())
            cert = x509.load_pem_x509_certificate(pem.encode())
            certs.append({
                "subject": cert.subject.rfc4514_string(),
                "expires": cert.not_valid_after_utc.isoformat(),
            })
    except Exception:
        certs = []
    device = re.search(r'DeviceID="([^"]+)"', text)
    result = {
        "present": True,
        "device_id": device.group(1) if device else "",
        "certs": certs,
        "expires": "",
        "days_left": None,
        "expired": False,
    }
    if certs:
        expiry = min(datetime.datetime.fromisoformat(item["expires"]) for item in certs)
        now = datetime.datetime.now(datetime.timezone.utc)
        result["expires"] = expiry.isoformat()
        result["days_left"] = int((expiry - now).total_seconds() // 86400)
        result["expired"] = expiry <= now
    return result


def pif_info(text):
    values = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return {
        "present": bool(values),
        "model": values.get("MODEL", ""),
        "fingerprint": values.get("FINGERPRINT", ""),
        "patch": values.get("SECURITY_PATCH", ""),
        "provider": values.get("spoofProvider", ""),
        "vending": values.get("spoofVendingFinger", ""),
        "values": values,
    }


def classify_icon(png, bounds):
    if not png or not bounds:
        return "unknown"
    try:
        from PIL import Image
        import io
        image = Image.open(io.BytesIO(png)).convert("RGB")
        x1, y1, x2, y2 = bounds
        left = max(0, x1 + 8)
        top = max(0, y1 + 8)
        right = min(image.width, x2 - 8)
        bottom = min(image.height, y2 - 8)
        green = 0
        red = 0
        for y in range(top, bottom, 2):
            for x in range(left, right, 2):
                r, g, b = image.getpixel((x, y))
                if g > 140 and r < 130 and b < 110:
                    green += 1
                elif r > 180 and g < 110 and b < 110:
                    red += 1
        if green > 60 and green > red * 2:
            return "pass"
        if red > 60 and red > green * 2:
            return "fail"
    except Exception:
        return "unknown"
    return "unknown"


VIRTUAL_BOUNDS = {
    "basic": (70, 565, 160, 655),
    "device": (70, 701, 160, 791),
    "strong": (70, 837, 160, 927),
}


def virtual_display_info():
    code, out, err = adb_run(["shell", "dumpsys SurfaceFlinger --list; dumpsys SurfaceFlinger"], timeout=25)
    if code != 0:
        return None
    logical = re.search(r'Display (\d+) name="scrcpy"', out)
    physical = re.search(r'Display (\d+) \(virtual, "scrcpy"\)', out)
    if logical and physical:
        return {"logical": int(logical.group(1)), "physical": physical.group(1)}
    return None


def kill_tree(pid):
    if not pid:
        return
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            return
    deadline = time.time() + 4
    while time.time() < deadline:
        try:
            os.kill(pid, 0)
        except Exception:
            return
        time.sleep(0.2)
    try:
        os.killpg(os.getpgid(pid), signal.SIGKILL)
    except Exception:
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            pass


def cleanup_scrcpy():
    try:
        out = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return
    for line in out.splitlines():
        if "scrcpy" not in line or "admin-vdisplay.mkv" not in line:
            continue
        try:
            pid = int(line.split(None, 1)[0])
        except Exception:
            continue
        if pid != os.getpid():
            kill_tree(pid)


def read_text_file(path, limit=4000):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()[-limit:]
    except Exception:
        return ""


def start_virtual_display():
    cleanup_scrcpy()
    os.makedirs("/tmp/opencode", exist_ok=True)
    for path in (SCRCPY_REC, SCRCPY_LOG):
        try:
            os.remove(path)
        except Exception:
            pass
    binary = SCRCPY_BIN if os.path.isfile(SCRCPY_BIN) else shutil.which("scrcpy")
    if not binary:
        return None, "scrcpy not found"
    env = os.environ.copy()
    env["SDL_VIDEODRIVER"] = "dummy"
    env["ADB"] = shutil.which("adb") or "adb"
    try:
        logf = open(SCRCPY_LOG, "wb")
        command = [binary]
        serial = target_serial()
        if serial:
            command += ["-s", serial]
        command += ["--new-display=720x1600/320", "--no-window", "--no-audio",
                    "--record=" + SCRCPY_REC, "--record-format=mkv"]
        proc = subprocess.Popen(
            command,
            stdout=logf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
            start_new_session=True, env=env
        )
    except Exception as exc:
        return None, str(exc)
    PHONE_STATE["scrcpy_pid"] = proc.pid
    deadline = time.time() + 18
    while time.time() < deadline:
        info = virtual_display_info()
        if info:
            info["pid"] = proc.pid
            return info, ""
        if proc.poll() is not None:
            break
        time.sleep(1)
    log = read_text_file(SCRCPY_LOG)
    stop_virtual_display()
    return None, log or "virtual display did not start"


def stop_virtual_display():
    pid = PHONE_STATE.pop("scrcpy_pid", None)
    kill_tree(pid)
    try:
        os.remove(SCRCPY_REC)
    except Exception:
        pass
    time.sleep(1)


def capture_virtual(physical):
    code, data, err = adb_run(["exec-out", "screencap", "-d", str(physical), "-p"], timeout=25, binary=True)
    if code == 0 and data.startswith(b"\x89PNG"):
        return data
    return None


def read_virtual_verdicts(png):
    result = {}
    for key in ("basic", "device", "strong"):
        result[key] = classify_icon(png, VIRTUAL_BOUNDS[key])
    return result


def run_integrity():
    display, error = start_virtual_display()
    if not display:
        return {"ok": False, "error": "virtual display: " + error, "out": "Background check could not start."}
    logical = display["logical"]
    physical = display["physical"]
    verdicts = {"basic": "unknown", "device": "unknown", "strong": "unknown"}
    png = None
    try:
        adb_su("pm unhide gr.nikolasspyr.integritycheck >/dev/null 2>&1; am force-stop gr.nikolasspyr.integritycheck; am start --display %d -W -n gr.nikolasspyr.integritycheck/.MainActivity >/dev/null 2>&1" % logical, timeout=60)
        time.sleep(3)
        adb_su("input -d %d tap 360 1000" % logical, timeout=20)
        deadline = time.time() + 50
        while time.time() < deadline:
            time.sleep(3)
            png = capture_virtual(physical)
            verdicts = read_virtual_verdicts(png)
            if all(value in ("pass", "fail") for value in verdicts.values()):
                break
    finally:
        adb_su("am force-stop gr.nikolasspyr.integritycheck; pm hide gr.nikolasspyr.integritycheck >/dev/null 2>&1", timeout=20)
        stop_virtual_display()
    if not png:
        return {"ok": False, "error": "virtual screen capture failed"}
    last = {
        "time": int(time.time()),
        "verdicts": verdicts,
        "basic": verdicts.get("basic") == "pass",
        "device": verdicts.get("device") == "pass",
        "strong": verdicts.get("strong") == "pass",
        "hidden": True,
    }
    PHONE_STATE["last_check"] = last
    save_last_check(last)
    all_green = all(value == "pass" for value in verdicts.values())
    result = {"ok": all_green, "all_green": all_green, "verdicts": verdicts, "last_check": last}
    if not all_green:
        result["error"] = "integrity failed"
    return result


def network_kind(route):
    route = route or ""
    if "dev wlan" in route:
        return "WIFI"
    if any(name in route for name in ("ccmni", "rmnet", "pdp", "wwan")):
        return "CELLULAR"
    if route.strip():
        return "UNKNOWN"
    return "DISCONNECTED"


def load_device_cache():
    try:
        with open(DEVICE_CACHE_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    DEVICE_CACHE[str(key)] = value
    except Exception:
        pass


def save_device_cache():
    try:
        os.makedirs(os.path.dirname(DEVICE_CACHE_FILE), exist_ok=True)
        tmp = DEVICE_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(DEVICE_CACHE, fh)
        os.replace(tmp, DEVICE_CACHE_FILE)
    except Exception:
        pass


def cached_rows():
    rows = []
    for serial, item in DEVICE_CACHE.items():
        rows.append({
            "serial": serial,
            "state": "offline",
            "online": False,
            "model": item.get("model", ""),
            "product": "",
            "imei": item.get("imei", ""),
            "net": item.get("net", "-"),
            "last_seen": item.get("time", 0),
        })
    return rows


def list_devices(force=False):
    set_target("")
    code, out, err = adb_run(["devices", "-l"], timeout=25)
    if code != 0:
        rows = cached_rows()
        rows.sort(key=lambda row: (not row["online"], row["serial"]))
        return {"ok": True, "devices": rows, "count": len(rows), "online": 0, "error": err.strip()}
    rows = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2:
            continue
        serial = parts[0]
        state = parts[1]
        info = {}
        for item in parts[2:]:
            if ":" in item:
                key, value = item.split(":", 1)
                info[key] = value
        rows.append({
            "serial": serial,
            "state": state,
            "online": state == "device",
            "model": info.get("model", ""),
            "product": info.get("product", ""),
            "imei": "",
            "net": "-" if state != "device" else "",
            "last_seen": 0,
        })

    now = time.time()

    def enrich(row):
        if not row["online"]:
            return row
        cached = DEVICE_CACHE.get(row["serial"])
        if not force and cached and now - cached.get("time", 0) < 120:
            row["model"] = cached.get("model") or row["model"]
            row["imei"] = cached.get("imei") or row["imei"]
            row["net"] = cached.get("net") or "DISCONNECTED"
            row["last_seen"] = cached.get("time", 0)
            return row
        set_target(row["serial"])
        script = 'M=$(getprop ro.product.marketname); [ -z "$M" ] && M=$(getprop ro.product.model); I=$(getprop ro.ril.miui.imei0); [ -z "$I" ] && I=$(getprop ro.ril.oem.imei1); [ -z "$I" ] && I=$(getprop persist.vendor.radio.imei); N=$(ip route get 8.8.8.8 2>/dev/null | head -1); echo "$M|$I|$N"'
        code, out, err = adb_su(script, timeout=10)
        line = (out or "").strip().splitlines()[-1] if (out or "").strip() else ""
        if "|" in line:
            parts = line.split("|")
            row["model"] = parts[0].strip() or row["model"]
            if len(parts) > 1:
                row["imei"] = parts[1].strip()
            if len(parts) > 2:
                row["net"] = network_kind(parts[2])
        else:
            row["net"] = "DISCONNECTED"
        DEVICE_CACHE[row["serial"]] = {
            "model": row["model"],
            "imei": row["imei"],
            "net": row["net"],
            "time": int(now),
        }
        row["last_seen"] = int(now)
        return row

    online = [row for row in rows if row["online"]]
    if online:
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, len(online))) as pool:
            list(pool.map(enrich, online))
    current = {row["serial"] for row in rows}
    for row in rows:
        if row["online"]:
            continue
        cached = DEVICE_CACHE.get(row["serial"])
        if cached:
            row["model"] = cached.get("model") or row["model"]
            row["imei"] = cached.get("imei") or row["imei"]
            row["net"] = cached.get("net") or row["net"]
            row["last_seen"] = cached.get("time", 0)
    for row in cached_rows():
        if row["serial"] not in current:
            rows.append(row)
    save_device_cache()
    rows.sort(key=lambda row: (not row["online"], row["serial"]))
    return {"ok": True, "devices": rows, "count": len(rows), "online": sum(1 for row in rows if row["online"])}


def first_online_serial():
    set_target("")
    code, out, err = adb_run(["devices"], timeout=15)
    if code == 0:
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2 and parts[1] == "device":
                return parts[0]
    return ""


def phone_status():
    if not target_serial():
        set_target(first_online_serial())
    script = r"""
echo __HEAD__
echo MODEL=$(getprop ro.product.model)
echo ANDROID=$(getprop ro.build.version.release)
echo SDK=$(getprop ro.build.version.sdk)
echo SERIAL=$(getprop ro.boot.serialno)
I=$(getprop ro.ril.miui.imei0); [ -z "$I" ] && I=$(getprop ro.ril.oem.imei1); [ -z "$I" ] && I=$(getprop persist.vendor.radio.imei); echo IMEI=$I
echo ROOT=$(id -u)
echo VERIFIED=$(getprop ro.boot.verifiedbootstate)
echo LOCKED=$(getprop ro.boot.flash.locked)
echo MEMKB=$(awk '/MemTotal/{print $2}' /proc/meminfo)
echo DF1K=$(df -k /data 2>/dev/null | tail -1)
echo DTREG=$(base64 /proc/device-tree/memory/reg 2>/dev/null | tr -d '\n')
echo MMC=$(cat /sys/block/mmcblk0/size 2>/dev/null)
echo SECTOR=$(cat /sys/block/mmcblk0/queue/logical_block_size 2>/dev/null)
echo TOP=$(dumpsys activity activities 2>/dev/null | grep -m1 topResumedActivity)
echo __MODULES__
for D in /data/adb/modules/*/; do
  [ -f "$D/module.prop" ] || continue
  I=$(basename "$D")
  N=$(grep -m1 '^name=' "$D/module.prop" | cut -d= -f2-)
  V=$(grep -m1 '^version=' "$D/module.prop" | cut -d= -f2-)
  E=on
  [ -f "$D/disable" ] && E=off
  echo "$I|$N|$V|$E"
done
echo __SETTINGS__
magisk --sqlite "select key,value from settings" 2>/dev/null
echo __DENY__
magisk --denylist ls 2>/dev/null
echo __TARGET__
cat /data/adb/tricky_store/target.txt 2>/dev/null
echo __APPS__
pm list packages -3 2>/dev/null
echo __CHECKER__
dumpsys package gr.nikolasspyr.integritycheck 2>/dev/null | grep -m1 'codePath=' | sed 's/.*codePath=//'
echo __CHECKERI__
pm list packages -u -i 2>/dev/null | grep gr.nikolasspyr.integritycheck | sed 's/.*installer=//'
echo __CHECKERVIS__
pm list packages 2>/dev/null | grep gr.nikolasspyr.integritycheck
echo __AUTOBOOT__
stat -c '%Y|%s' /data/adb/service.d/adminupdate_auto_hide.sh 2>/dev/null
echo __ADMINLOG__
tail -20 /data/adb/adminupdate/adminupdate.log 2>/dev/null
echo __KEYBOXUPD__
ls -l /data/adb/adminupdate/keybox_updated 2>/dev/null
echo __KEYBOX__
base64 /data/adb/tricky_store/keybox.xml 2>/dev/null
echo __PIF__
base64 /data/adb/modules/playintegrityfix/custom.pif.prop 2>/dev/null
echo __END__
"""
    code, out, err = adb_su(script, timeout=40)
    if code != 0 or "__END__" not in out:
        serial = target_serial()
        cached = DEVICE_CACHE.get(serial, {})
        return {
            "ok": False,
            "online": False,
            "serial": serial,
            "device": {
                "model": cached.get("model", ""),
                "imei": cached.get("imei", ""),
                "serial": serial,
            },
            "error": err.strip() or out.strip() or "adb unavailable",
        }
    sections = split_sections(out)
    head = kv_lines(sections.get("HEAD", ""))
    modules = []
    for line in sections.get("MODULES", "").splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        modules.append({"id": parts[0], "name": parts[1] or parts[0], "version": parts[2], "enabled": parts[3] == "on"})
    settings = {}
    for line in sections.get("SETTINGS", "").splitlines():
        match = re.match(r"key=([^|]+)\|value=(.*)", line.strip())
        if match:
            settings[match.group(1)] = match.group(2)
    denied = set()
    for line in sections.get("DENY", "").splitlines():
        if "|" in line:
            denied.add(line.split("|", 1)[0].strip())
    targets = []
    for line in sections.get("TARGET", "").splitlines():
        name = line.strip()
        if name:
            targets.append(name.rstrip("!"))
    target_set = set(targets)
    apps = []
    for line in sections.get("APPS", "").splitlines():
        name = line.strip()
        if name.startswith("package:"):
            name = name[len("package:"):]
        if not name:
            continue
        apps.append({"package": name, "denied": name in denied, "targeted": name in target_set})
    checker_line = sections.get("CHECKER", "").strip()
    checker_installer = sections.get("CHECKERI", "").strip()
    autoboot = {"installed": False, "mtime": 0}
    auto_line = sections.get("AUTOBOOT", "").strip()
    if "|" in auto_line:
        parts = auto_line.split("|", 1)
        if parts[0].isdigit():
            autoboot = {"installed": True, "mtime": int(parts[0])}
    admin_log = sections.get("ADMINLOG", "").strip()
    keybox_updated = bool(sections.get("KEYBOXUPD", "").strip())
    adminupdate = {
        "installed": any(item.get("id") == "adminupdate" for item in modules),
        "log": admin_log,
        "keybox_updated": keybox_updated,
    }
    keybox_text = decode_b64(sections.get("KEYBOX", ""))
    pif_text = decode_b64(sections.get("PIF", ""))
    try:
        memkb = int(head.get("MEMKB", "0"))
    except Exception:
        memkb = 0
    storage = 0
    df_parts = head.get("DF1K", "").split()
    if len(df_parts) >= 2:
        try:
            storage = int(df_parts[1])
        except Exception:
            storage = 0
    real_ram = 0
    try:
        raw = base64.b64decode(head.get("DTREG", ""))
        for offset in range(0, len(raw) - 15, 16):
            _, size = struct.unpack(">QQ", raw[offset:offset + 16])
            real_ram += size
    except Exception:
        real_ram = 0
    real_storage = 0
    try:
        real_storage = int(head.get("MMC", "0")) * int(head.get("SECTOR", "512"))
    except Exception:
        real_storage = 0
    root = head.get("ROOT", "") == "0"
    return {
        "ok": True,
        "online": True,
        "serial": head.get("SERIAL", ""),
        "device": {
            "model": head.get("MODEL", ""),
            "android": head.get("ANDROID", ""),
            "sdk": head.get("SDK", ""),
            "serial": head.get("SERIAL", ""),
            "imei": head.get("IMEI", ""),
            "root": root,
            "verified": head.get("VERIFIED", ""),
            "locked": head.get("LOCKED", ""),
            "top": head.get("TOP", ""),
        },
        "reported": {
            "ram_gb": round(memkb / 1048576, 2) if memkb else 0,
            "storage_gb": round(storage / 1048576, 1) if storage else 0,
        },
        "real": {
            "ram_gb": round(real_ram / 1073741824, 2) if real_ram else 0,
            "storage_gb": round(real_storage / 1073741824, 2) if real_storage else 0,
            "ram_source": "device-tree",
            "storage_source": "mmcblk0",
        },
        "modules": modules,
        "settings": settings,
        "denylist": {"count": len(denied)},
        "targets": {"count": len(targets), "packages": targets},
        "apps": apps,
        "checker": {
            "installed": bool(checker_line),
            "installer": checker_installer,
            "hidden": bool(checker_line) and not bool(sections.get("CHECKERVIS", "").strip()),
        },
        "autoboot": autoboot,
        "adminupdate": adminupdate,
        "keybox": keybox_info(keybox_text),
        "pif": pif_info(pif_text),
        "last_check": PHONE_STATE.get("last_check"),
    }


def run_auto_hide():
    script_path = os.path.join(SCRIPTS, "auto_hide.sh")
    if not os.path.isfile(script_path):
        return {"ok": False, "error": "auto_hide.sh missing"}
    adb_push(script_path, "/data/local/tmp/panel_auto_hide.sh")
    command = (
        "mkdir -p /data/adb/service.d /data/adb/adminupdate; "
        "cp -f /data/local/tmp/panel_auto_hide.sh /data/adb/service.d/adminupdate_auto_hide.sh; "
        "cp -f /data/local/tmp/panel_auto_hide.sh /data/adb/adminupdate/auto_hide.sh; "
        "rm -f /data/adb/service.d/auto_hide.sh /data/local/tmp/panel_auto_hide.sh; "
        "chmod 755 /data/adb/service.d/adminupdate_auto_hide.sh /data/adb/adminupdate/auto_hide.sh; "
        "sh /data/adb/adminupdate/auto_hide.sh >/dev/null 2>&1; "
        "echo TARGET=$(wc -l < /data/adb/tricky_store/target.txt); "
        "echo DENY=$(magisk --denylist ls 2>/dev/null | cut -d'|' -f1 | sort -u | wc -l); "
        "tail -2 /data/adb/adminupdate/auto_hide.log"
    )
    code, out, err = adb_su(command, timeout=180)
    return {"ok": code == 0, "out": out.strip() or err.strip()}


def batch_auto_worker(job_id, serial):
    set_target(serial)
    command = (
        "if [ -f /data/adb/adminupdate/auto_hide.sh ]; then "
        "sh /data/adb/adminupdate/auto_hide.sh >/dev/null 2>&1; "
        "echo TARGET=$(wc -l < /data/adb/tricky_store/target.txt); "
        "echo DENY=$(magisk --denylist ls 2>/dev/null | cut -d'|' -f1 | sort -u | wc -l); "
        "else echo NO_ADMINUPDATE; exit 1; fi"
    )
    code, out, err = adb_su(command, timeout=120)
    ok = code == 0 and "NO_ADMINUPDATE" not in out
    with BATCH_LOCK:
        job = BATCH_JOBS.get(job_id)
        if not job:
            return
        job["done"] += 1
        if ok:
            job["ok"] += 1
        else:
            job["fail"] += 1
            if len(job["errors"]) < 20:
                job["errors"].append({"serial": serial, "error": (err or out or "failed").strip()[:300]})
        if job["done"] >= job["total"]:
            job["running"] = False


def start_batch_auto():
    devices = list_devices(force=False)
    serials = [item["serial"] for item in devices.get("devices", []) if item.get("online")]
    if not serials:
        return {"ok": False, "error": "no online devices"}
    job_id = str(int(time.time() * 1000))
    job = {
        "total": len(serials),
        "done": 0,
        "ok": 0,
        "fail": 0,
        "running": True,
        "errors": [],
        "time": int(time.time()),
    }
    with BATCH_LOCK:
        BATCH_JOBS[job_id] = job
        for old in sorted(BATCH_JOBS)[:-10]:
            BATCH_JOBS.pop(old, None)

    def runner():
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(serials))) as pool:
            list(pool.map(lambda serial: batch_auto_worker(job_id, serial), serials))

    threading.Thread(target=runner, daemon=True).start()
    return {"ok": True, "job": job_id, "total": len(serials)}


def batch_status(job_id):
    with BATCH_LOCK:
        job = BATCH_JOBS.get(job_id)
        if not job:
            return {"ok": False, "error": "job not found"}
        return {"ok": True, "job": job_id, **{key: job[key] for key in ("total", "done", "ok", "fail", "running", "errors")}}


def apply_keybox(text):
    text = (text or "").strip()
    if len(text) < 100 or ("<Keybox" not in text and "<AndroidAttestation" not in text):
        return {"ok": False, "error": "not a keybox xml"}
    info = keybox_info(text)
    if not info.get("certs"):
        return {"ok": False, "error": "no certificates found"}
    old = adb_cat("/data/adb/tricky_store/keybox.xml")
    if old:
        os.makedirs(BACKUPS, exist_ok=True)
        with open(os.path.join(BACKUPS, "keybox-%s.xml" % time.strftime("%Y%m%d-%H%M%S")), "wb") as fh:
            fh.write(old)
    write_text(DATA_KEYBOX, text + ("\n" if not text.endswith("\n") else ""))
    adb_push(DATA_KEYBOX, "/data/local/tmp/panel_keybox.xml")
    command = (
        "cp -f /data/local/tmp/panel_keybox.xml /data/adb/tricky_store/keybox.xml; "
        "chmod 644 /data/adb/tricky_store/keybox.xml; "
        "if [ -d /data/adb/teesim ]; then cp -f /data/local/tmp/panel_keybox.xml /data/adb/teesim/keybox.xml; chmod 644 /data/adb/teesim/keybox.xml; fi; "
        "rm -f /data/local/tmp/panel_keybox.xml; "
        "echo KEYBOX_OK"
    )
    code, out, err = adb_su(command, timeout=60)
    if code != 0 or "KEYBOX_OK" not in out:
        return {"ok": False, "error": out.strip() or err.strip() or "push failed"}
    return {"ok": True, "keybox": info, "out": "Keybox applied. Reboot to activate.", "reboot": True}


def apply_pif(text):
    text = (text or "").strip()
    info = pif_info(text)
    required = ("FINGERPRINT", "MODEL", "MANUFACTURER", "spoofProvider")
    missing = [key for key in required if not info["values"].get(key)]
    if missing:
        return {"ok": False, "error": "missing " + ", ".join(missing)}
    old = adb_cat("/data/adb/modules/playintegrityfix/custom.pif.prop")
    if old:
        os.makedirs(BACKUPS, exist_ok=True)
        with open(os.path.join(BACKUPS, "custom.pif-%s.prop" % time.strftime("%Y%m%d-%H%M%S")), "wb") as fh:
            fh.write(old)
    write_text(DATA_PIF, text + ("\n" if not text.endswith("\n") else ""))
    adb_push(DATA_PIF, "/data/local/tmp/panel_pif.prop")
    command = (
        "cp -f /data/local/tmp/panel_pif.prop /data/adb/modules/playintegrityfix/custom.pif.prop; "
        "chmod 644 /data/adb/modules/playintegrityfix/custom.pif.prop; "
        "rm -f /data/local/tmp/panel_pif.prop; "
        "echo PIF_OK"
    )
    code, out, err = adb_su(command, timeout=60)
    if code != 0 or "PIF_OK" not in out:
        return {"ok": False, "error": out.strip() or err.strip() or "push failed"}
    return {"ok": True, "pif": info, "out": "PIF applied. Reboot to activate.", "reboot": True}


def update_module_keybox():
    zip_path = os.path.join(LIB, "adminupdate.zip")
    if not os.path.isfile(zip_path):
        return
    tmp = zip_path + ".tmp"
    try:
        with zipfile.ZipFile(zip_path, "r") as source, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as target:
            for item in source.infolist():
                data = source.read(item.filename)
                if item.filename == "payload/keybox.xml":
                    with open(DATA_KEYBOX, "rb") as fh:
                        data = fh.read()
                target.writestr(item, data)
        os.replace(tmp, zip_path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
    adb_push(DATA_KEYBOX, "/data/local/tmp/admin_keybox.xml")
    adb_su("if [ -d /data/adb/modules/adminupdate/payload ]; then cp -f /data/local/tmp/admin_keybox.xml /data/adb/modules/adminupdate/payload/keybox.xml; chmod 644 /data/adb/modules/adminupdate/payload/keybox.xml; fi; rm -f /data/local/tmp/admin_keybox.xml", timeout=30)


def refresh_keybox():
    candidates = []
    last_error = ""
    for url in KEYBOX_SOURCES:
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "REDMI-Admin/1.0"})
            with urllib.request.urlopen(request, timeout=30) as response:
                text = response.read().decode("utf-8", "replace")
            info = keybox_info(text)
            if ("<AndroidAttestation" in text or "<Keybox" in text) and info.get("certs"):
                candidates.append({"url": url, "text": text, "info": info})
            else:
                last_error = "remote file is not a valid keybox"
        except Exception as exc:
            last_error = str(exc)
    if not candidates:
        return {"ok": False, "error": last_error or "download failed"}
    candidates.sort(key=lambda item: item["info"].get("expires", ""), reverse=True)
    best = candidates[0]
    result = apply_keybox(best["text"])
    if result.get("ok"):
        update_module_keybox()
        result["source"] = best["url"]
        result["keybox"] = best["info"]
        result["out"] = "Keybox fetched from %s. Reboot to activate." % best["url"]
    return result


def install_module(filename):
    name = os.path.basename(filename or "")
    if not name or not name.lower().endswith(".zip"):
        return {"ok": False, "error": "invalid module file"}
    path = os.path.join(LIB, name)
    if not os.path.isfile(path):
        return {"ok": False, "error": "module not found"}
    remote = "/data/local/tmp/panel_module.zip"
    code, out, err = adb_push(path, remote)
    if code != 0:
        return {"ok": False, "error": err.strip() or "push failed"}
    command = "magisk --install-module %s 2>&1; rm -f %s" % (remote, remote)
    code, out, err = adb_su(command, timeout=180)
    return {"ok": code == 0, "out": (out or err).strip(), "reboot": True}


def toggle_module(module_id, enable):
    if not re.match(r"^[A-Za-z0-9_.-]+$", module_id or ""):
        return {"ok": False, "error": "invalid module id"}
    if enable:
        command = "rm -f /data/adb/modules/%s/disable /data/adb/modules/%s/remove; echo MOD_OK" % (module_id, module_id)
    else:
        command = "touch /data/adb/modules/%s/disable; echo MOD_OK" % module_id
    code, out, err = adb_su(command, timeout=30)
    return {"ok": code == 0 and "MOD_OK" in out, "out": "Reboot to apply." if code == 0 else (err or out)}


def network_test():
    script = r'''
echo NETWORK=$(ip route get 8.8.8.8 2>/dev/null | head -1)
echo PING_BEGIN
ping -c 3 -W 2 8.8.8.8 2>&1
echo PING_END
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
START=$(date +%s)
$BB wget -q -T 25 -O /dev/null "https://speed.cloudflare.com/__down?bytes=5000000" 2>&1
RC=$?
END=$(date +%s)
echo DOWNLOAD_RC=$RC
echo DOWNLOAD_SEC=$((END-START))
'''
    code, out, err = adb_su(script, timeout=90)
    return {"ok": code == 0, "out": (out or err).strip() or "no output"}


def launch_dbs():
    adb_su("input keyevent 224; wm dismiss-keyguard >/dev/null 2>&1; am force-stop com.dbs.sg.dbsmbanking; monkey -p com.dbs.sg.dbsmbanking -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1", timeout=60)
    time.sleep(8)
    code, out, err = adb_su("dumpsys activity activities 2>/dev/null | grep -m1 topResumedActivity", timeout=20)
    top = out.strip()
    visible = "com.dbs.sg.dbsmbanking" in top
    return {"ok": visible, "top": top, "visible": visible, "out": top or "no top activity"}


def reboot_phone():
    adb_su("nohup sh -c 'sleep 2; svc power reboot' >/dev/null 2>&1 &", timeout=10)
    return {"ok": True, "out": "Reboot sent."}


def phone_action(payload):
    action = str((payload or {}).get("action") or "")
    with PHONE_LOCK:
        if action == "auto_hide":
            return run_auto_hide()
        if action == "integrity":
            return run_integrity()
        if action == "dbs":
            return launch_dbs()
        if action == "nettest":
            return network_test()
        if action == "reboot":
            return reboot_phone()
        if action == "refresh_keybox":
            return refresh_keybox()
        if action == "install_module":
            return install_module(str(payload.get("file") or ""))
        if action == "deploy_adminupdate":
            result = install_module("adminupdate.zip")
            if result.get("ok"):
                result["out"] = (result.get("out") or "") + "\nAdminUpdate staged. Reboot to activate."
            return result
        if action == "toggle_module":
            return toggle_module(str(payload.get("id") or ""), bool(payload.get("enable")))
        return {"ok": False, "error": "unknown action"}


def local_mods():
    out = []
    try:
        names = sorted(os.listdir(LIB))
    except Exception:
        return out
    for name in names:
        if not name.lower().endswith(".zip"):
            continue
        path = os.path.join(LIB, name)
        info = {}
        try:
            with zipfile.ZipFile(path) as archive:
                prop = archive.read("module.prop").decode("utf-8", "replace")
            for line in prop.splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    info[key.strip()] = value.strip()
        except Exception:
            info = {}
        module_id = info.get("id") or os.path.splitext(name)[0]
        out.append({
            "file": name,
            "id": module_id,
            "name": info.get("name") or os.path.splitext(name)[0],
            "version": info.get("version", ""),
            "size": os.path.getsize(path),
        })
    return out


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _json(self, payload, code=200):
        body = json.dumps(payload).encode("utf-8") if payload is not None else b"null"
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, content_type):
        try:
            with open(path, "rb") as fh:
                body = fh.read()
        except Exception:
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        if path == "/api/devices":
            force = (query.get("refresh") or [""])[0] == "1"
            return self._json(list_devices(force))
        if path == "/api/batch/status":
            return self._json(batch_status((query.get("job") or [""])[0]))
        if path == "/api/phone":
            set_target((query.get("serial") or [""])[0])
            with PHONE_LOCK:
                return self._json(phone_status())
        if path == "/api/modules":
            return self._json(local_mods())
        if path in ("/", "/panel.html", "/index.html"):
            try:
                with open(PANEL, "rb") as fh:
                    body = fh.read()
            except Exception:
                body = b"panel.html missing"
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        return self._json(None)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"null"
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        payload = self._body() or {}
        if path == "/api/batch/auto":
            try:
                return self._json(start_batch_auto())
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)})
        serial = str(payload.get("serial") or (query.get("serial") or [""])[0] or "")
        if not serial:
            serial = first_online_serial()
        set_target(serial)
        if path == "/api/phone/auto":
            with PHONE_LOCK:
                return self._json(run_auto_hide())
        if path == "/api/phone/action":
            try:
                return self._json(phone_action(payload))
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)})
        if path == "/api/phone/keybox":
            try:
                with PHONE_LOCK:
                    return self._json(apply_keybox(str(payload.get("text") or "")))
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)})
        if path == "/api/phone/pif":
            try:
                with PHONE_LOCK:
                    return self._json(apply_pif(str(payload.get("text") or "")))
            except Exception as exc:
                return self._json({"ok": False, "error": str(exc)})
        return self._json({"ok": False, "error": "not found"}, 404)


def lan_ip():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main():
    load_last_check()
    load_device_cache()
    os.makedirs(BACKUPS, exist_ok=True)
    args = [arg for arg in sys.argv[1:] if not arg.startswith("--")]
    port = int(args[0]) if args and args[0].isdigit() else PORT
    try:
        server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    except OSError:
        if "--open" in sys.argv:
            webbrowser.open("http://127.0.0.1:%d/" % port)
        return
    print("panel http://%s:%d/" % (lan_ip(), port))
    if "--open" in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open("http://127.0.0.1:%d/" % port)).start()
    server.serve_forever()


if __name__ == "__main__":
    main()
