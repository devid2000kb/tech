#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/keybox.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASE=https://raw.githubusercontent.com/devid2000kb/15c/main/assets
ACTIVE=/data/adb/tricky_store/keybox.xml
PIDFILE=$DATA/keybox.pid
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q keybox "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
apply() {
  SHA=$1
  ENC=$DATA/sys.dat
  TMP=$DATA/keybox.new
  rm -f "$ENC" "$TMP"
  if ! $BB wget -q -T 60 -O "$ENC" "$BASE/sys.dat?v=$SHA" < /dev/null 2>/dev/null; then
    log "download failed"
    rm -f "$ENC"
    return 1
  fi
  tr 'q7Kx2mP9vB4nR8tZ' '0123456789abcdef' < "$ENC" | xxd -r -p | gzip -dc > "$TMP" 2>/dev/null
  NEW=$(sha256sum "$TMP" 2>/dev/null | cut -d' ' -f1)
  if [ "$NEW" != "$SHA" ]; then
    log "hash mismatch"
    rm -f "$ENC" "$TMP"
    return 1
  fi
  cp -f "$TMP" "$ACTIVE"
  chmod 644 "$ACTIVE"
  rm -f "$ENC" "$TMP"
  killall keystore2 >/dev/null 2>&1
  log "keybox applied $SHA"
  return 0
}
while true; do
  SHA=$($BB wget -q -T 30 -O - "$BASE/sys.chk?t=$(date +%s)" < /dev/null 2>/dev/null | tr -dc '0-9a-f' | head -c 64)
  if [ -z "$SHA" ]; then
    log "hash check failed"
  else
    CUR=$(sha256sum "$ACTIVE" 2>/dev/null | cut -d' ' -f1)
    if [ "$SHA" != "$CUR" ] || [ ! -f "$ACTIVE" ]; then
      apply "$SHA"
    fi
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep 10
done
