#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/pif.log
STAMP=$DATA/pif_stamp
BACKUP=$DATA/pif_backup.prop
PIF=/data/adb/modules/playintegrityfix/custom.pif.prop
MOD=/data/adb/modules/playintegrityfix
INTERVAL=2592000
PIDFILE=$DATA/pif.pid
mkdir -p "$DATA"
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q pif.sh "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
write_fallback() {
cat > "$PIF" <<'PIFEOF'
MANUFACTURER=Google
MODEL=Pixel 7 Pro
FINGERPRINT=google/cheetah_beta/cheetah:CANARY/ZP11.261016.008/16754936:user/release-keys
BRAND=google
PRODUCT=cheetah_beta
DEVICE=cheetah
RELEASE=CANARY
ID=ZP11.261016.008
INCREMENTAL=16754936
TYPE=user
TAGS=release-keys
SECURITY_PATCH=2026-11-05
DEVICE_INITIAL_SDK_INT=33
ro.build.fingerprint=google/cheetah_beta/cheetah:CANARY/ZP11.261016.008/16754936:user/release-keys
ro.build.id=ZP11.261016.008
ro.product.device=cheetah
ro.product.name=cheetah_beta
ro.build.version.security_patch=2026-11-05
ro.board.first_api_level=32
ro.product.first_api_level=33
spoofBuild=1
spoofProps=1
spoofProvider=0
spoofSignature=0
spoofVendingFinger=1
spoofVendingSdk=0
verboseLogs=0
PIFEOF
chmod 644 "$PIF"
}
if [ ! -f "$PIF" ]; then
  write_fallback
  log "fallback PIF installed; rebooting"
  sleep 2
  svc power reboot
  exit 0
fi
[ -f "$BACKUP" ] || cp -f "$PIF" "$BACKUP"
while true; do
  NOW=$(date +%s)
  LAST=$(cat "$STAMP" 2>/dev/null)
  [ -z "$LAST" ] && LAST=0
  if [ "$LAST" = "0" ]; then
    date +%s > "$STAMP"
    LAST=$NOW
  fi
  if [ $((NOW - LAST)) -ge "$INTERVAL" ]; then
    cp -f "$PIF" "$BACKUP"
    if [ -f "$MOD/autopif4.sh" ]; then
      ( cd "$MOD" && sh autopif4.sh --strong ) >>"$LOG" 2>&1
    fi
    if [ -f "$PIF" ] && ! cmp -s "$PIF" "$BACKUP"; then
      date +%s > "$STAMP"
      log "new PIF applied; rebooting"
      cmd notification post -t "PIF rotation" system "Rebooting to apply new PIF" >/dev/null 2>&1
      sleep 10
      svc power reboot
      exit 0
    fi
    date +%s > "$STAMP"
  fi
  sleep 3600
done
