#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/pif.log
STAMP=$DATA/pif_stamp
PIF=/data/adb/modules/playintegrityfix/custom.pif.prop
MOD=/data/adb/modules/playintegrityfix
INTERVAL=2592000
CHECK=21600
PIDFILE=$DATA/pif.pid
SDK=$(getprop ro.build.version.sdk)
mkdir -p "$DATA"
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q pif.sh "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
clean() {
  rm -f "$MOD/custom.pif.prop.bak" "$MOD/example.pif.prop" "$MOD/autopif4/custom.pif.prop" "$MOD/autopif4/pif.prop" 2>/dev/null
  rm -f "$DATA/pif_backup.prop" "$DATA/pif_good.prop" "$DATA/pif_saved.prop" 2>/dev/null
}
apply_hot() {
  killall com.google.android.gms.unstable >/dev/null 2>&1
  am force-stop com.google.android.gms >/dev/null 2>&1
  am force-stop com.android.vending >/dev/null 2>&1
  sleep 3
}
run_gen() {
  ( cd "$MOD" && sh autopif4.sh --strong ) >>"$LOG" 2>&1
  if [ -s "$PIF" ]; then
    sed -i 's/^spoofVendingFinger=.*/spoofVendingFinger=1/' "$PIF" 2>/dev/null
  fi
  clean
}
gen_match() {
  run_gen
  [ -s "$PIF" ] || return 1
  F=$(grep -m1 '^DEVICE_INITIAL_SDK_INT=' "$PIF" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  [ -n "$F" ] && [ "$F" -le "$SDK" ] && return 0
  return 1
}
gen_any() {
  run_gen
  [ -s "$PIF" ]
}
make_pif() {
  I=0
  while [ "$I" -lt 10 ]; do
    I=$((I+1))
    gen_match && return 0
    sleep 5
  done
  gen_any
}
rotate() {
  OLD=$(sha256sum "$PIF" 2>/dev/null | cut -d' ' -f1)
  make_pif
  NEW=$(sha256sum "$PIF" 2>/dev/null | cut -d' ' -f1)
  date +%s > "$STAMP"
  if [ "$OLD" != "$NEW" ]; then
    apply_hot
    log "PIF rotated and applied"
  fi
}
clean
NEED=0
[ -s "$PIF" ] || NEED=1
if [ -s "$PIF" ]; then
  F=$(grep -m1 '^DEVICE_INITIAL_SDK_INT=' "$PIF" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  [ -n "$F" ] && [ "$F" -gt "$SDK" ] && NEED=1
fi
if [ "$NEED" = "1" ]; then
  log "generating PIF for SDK $SDK"
  until make_pif; do
    log "generation failed; retrying in 60s"
    sleep 60
  done
  apply_hot
  date +%s > "$STAMP"
  log "PIF ready and applied"
fi
while true; do
  NOW=$(date +%s)
  LAST=$(cat "$STAMP" 2>/dev/null)
  [ -z "$LAST" ] && LAST=0
  if [ "$LAST" = "0" ]; then
    date +%s > "$STAMP"
    LAST=$NOW
  fi
  NEED=0
  EXP=$(sed -n 's/^# Estimated Expiry: //p' "$PIF" 2>/dev/null | head -1)
  if [ -n "$EXP" ]; then
    EXPTS=$(date -d "$EXP" +%s 2>/dev/null)
    if [ -n "$EXPTS" ] && [ "$EXPTS" -gt 0 ]; then
      [ $((EXPTS - NOW)) -le 604800 ] && NEED=1
    fi
  fi
  [ $((NOW - LAST)) -ge "$INTERVAL" ] && NEED=1
  if [ "$NEED" = "1" ]; then
    rotate
  fi
  sleep "$CHECK"
done
