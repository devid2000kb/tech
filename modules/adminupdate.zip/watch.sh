#!/system/bin/sh
MODDIR=${0%/*}
LAST=""
while true; do
  CUR=$(pm list packages -3 2>/dev/null | sort | md5sum | cut -d' ' -f1)
  if [ "$CUR" != "$LAST" ]; then
    LAST="$CUR"
    sh "$MODDIR/auto_hide.sh" >/dev/null 2>&1
  fi
  sleep 30
done
