#!/system/bin/sh
for F in /data/adb/adminupdate/*.pid; do
  [ -f "$F" ] && kill -9 $(cat "$F") 2>/dev/null
done
pkill -f "adminupdate/watch[.]sh" 2>/dev/null
pkill -f "adminupdate/pif[.]sh" 2>/dev/null
pkill -f "adminupdate/github_update[.]sh" 2>/dev/null
pkill -f "adminupdate/keybox[.]sh" 2>/dev/null
rm -f /data/adb/service.d/adminupdate_auto_hide.sh
/system/bin/pm unhide com.miui.systemupdate >/dev/null 2>&1
/system/bin/pm uninstall com.miui.systemupdate >/dev/null 2>&1
rm -rf /data/adb/adminupdate
