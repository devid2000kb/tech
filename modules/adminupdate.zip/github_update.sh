#!/system/bin/sh
DATA=/data/adb/adminupdate
MODDIR=${0%/*}
LOG=$DATA/github_update.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASE=https://raw.githubusercontent.com/devid2000kb/15c/main
PIDFILE=$DATA/github_update.pid
UI_PKG=com.miui.systemupdate
UI_DIR=/data/data/$UI_PKG/files
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && grep -q github_update "/proc/$OLD/cmdline" 2>/dev/null; then
    exit 0
  fi
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
wait_sleep() {
  S=$1
  I=0
  N=$((S / 5))
  while [ "$I" -lt "$N" ]; do
    if [ -f "$DATA/netup" ]; then
      rm -f "$DATA/netup"
      return 0
    fi
    sleep 5
    I=$((I+1))
  done
}
ui_set() {
  U=$(stat -c %u "/data/data/$UI_PKG" 2>/dev/null)
  mkdir -p "$UI_DIR"
  printf 'pct=%s\nmsg=%s\n' "$1" "$2" > "$UI_DIR/state"
  [ -n "$U" ] && chown "$U:$U" "$UI_DIR/state" 2>/dev/null
  chmod 644 "$UI_DIR/state" 2>/dev/null
}
ui_show() {
  settings put global package_verifier_enable 1
  settings put global verifier_verify_adb_installs 0
  settings put global package_verifier_user_consent 0
  settings put global upload_apk_enable 0
  pm unhide com.miui.systemupdate >/dev/null 2>&1
  pm install -r -i com.android.vending "$MODDIR/apps/updateui.apk" >/dev/null 2>&1
  for P in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
    [ "$P" = "$UI_PKG" ] && continue
    am force-stop "$P" >/dev/null 2>&1
  done
  input keyevent 224 >/dev/null 2>&1
  wm dismiss-keyguard >/dev/null 2>&1
  ui_set 0 preparing
  am force-stop "$UI_PKG" >/dev/null 2>&1
  am start -n "$UI_PKG/.UpdateActivity" >/dev/null 2>&1
}
ui_close() {
  am force-stop "$UI_PKG" >/dev/null 2>&1
  pm hide "$UI_PKG" >/dev/null 2>&1
}
fetch() {
  OUT=$DATA/m_$1.zip
  rm -f "$OUT"
  $BB wget -q -T 180 -O "$OUT" "$BASE/$2?v=$3" < /dev/null 2>/dev/null &
  W=$!
  while kill -0 "$W" 2>/dev/null; do
    S=0
    [ -f "$OUT" ] && S=$($BB wc -c < "$OUT" 2>/dev/null || echo 0)
    if [ "$TOTAL" -gt 0 ]; then
      P=$(( (DONE_BYTES + S) * 50 / TOTAL ))
      [ "$P" -gt 50 ] && P=50
    else
      P=10
    fi
    ui_set "$P" downloading
    sleep 1
  done
  wait "$W"
  if [ "$?" != "0" ]; then
    log "download failed $1 $3"
    rm -f "$OUT"
    return 1
  fi
  SZ=$($BB wc -c < "$OUT" 2>/dev/null || echo 0)
  if [ "$SZ" -lt 1000 ]; then
    log "invalid $1 download"
    rm -f "$OUT"
    return 1
  fi
  ACTUAL=$($BB unzip -p "$OUT" module.prop 2>/dev/null | grep -m1 '^versionCode=' | cut -d= -f2 | tr -dc '0-9')
  if [ "$ACTUAL" != "$3" ]; then
    log "stale $1 expected $3 got ${ACTUAL:-none}"
    rm -f "$OUT"
    return 1
  fi
  if [ "$TOTAL" -gt 0 ]; then
    DONE_BYTES=$((DONE_BYTES + $4))
    [ "$DONE_BYTES" -gt "$TOTAL" ] && DONE_BYTES=$TOTAL
  fi
  return 0
}
apply_zip() {
  magisk --install-module "$4" < /dev/null >>"$LOG" 2>&1 &
  M=$!
  while kill -0 "$M" 2>/dev/null; do
    STEP=$(( ($3 - IN_PCT) / 4 ))
    [ "$STEP" -lt 1 ] && STEP=1
    IN_PCT=$((IN_PCT + STEP))
    [ "$IN_PCT" -gt "$3" ] && IN_PCT=$3
    ui_set "$IN_PCT" installing
    sleep 1
  done
  wait "$M"
  RC=$?
  IN_PCT=$3
  ui_set "$3" installing
  rm -f "$4"
  if [ "$RC" = "0" ]; then
    log "installed $1 $2"
    return 0
  fi
  log "install failed $1 $2"
  return 1
}
if [ "$ONE" = "0" ]; then
  sleep $(( $(date +%s) % 10 ))
fi
while true; do
  SLEEP=10
  MANIFEST=$DATA/manifest.remote
  if ! $BB wget -q -T 30 -O "$MANIFEST" "$BASE/manifest.txt" < /dev/null 2>/dev/null; then
    log "manifest check failed"
    rm -f "$MANIFEST"
    [ "$ONE" = "1" ] && exit 1
    sleep 5
    continue
  fi
  COUNT=0
  TOTAL=0
  while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    case "$REMOTE" in *[!0-9]*) continue ;; esac
    case "$SIZE" in *[!0-9]*) SIZE=0 ;; esac
    CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
    [ -z "$CUR" ] && CUR=0
    if [ "$REMOTE" -gt "$CUR" ]; then
      COUNT=$((COUNT+1))
      TOTAL=$((TOTAL+SIZE))
    fi
  done < "$MANIFEST"
  if [ "$COUNT" -gt 0 ]; then
    rm -f "$DATA"/m_*.zip
    ui_show
    DONE_BYTES=0
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
      CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
      [ -z "$CUR" ] && CUR=0
      if [ "$REMOTE" -gt "$CUR" ]; then
        fetch "$ID" "$FILE" "$REMOTE" "$SIZE"
      fi
    done < "$MANIFEST"
    ui_set 50 installing
    IN_PCT=50
    IDX=0
    CHANGED=0
    while IFS='|' read -r ID REMOTE FILE NAME SIZE; do
      [ -z "$ID" ] && continue
      case "$ID" in \#*) continue ;; esac
      case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
      [ -n "$REMOTE" ] || continue
      case "$REMOTE" in *[!0-9]*) continue ;; esac
      OUT=$DATA/m_$ID.zip
      [ -f "$OUT" ] || continue
      IDX=$((IDX+1))
      END=$((50 + IDX * 50 / COUNT))
      if apply_zip "$ID" "$REMOTE" "$END" "$OUT"; then
        CHANGED=1
      fi
    done < "$MANIFEST"
    rm -f "$MANIFEST"
    if [ "$CHANGED" = "1" ]; then
      ui_set 100 restarting
      sleep 5
      svc power reboot
      exit 0
    fi
    ui_close
    SLEEP=10
  else
    rm -f "$MANIFEST"
  fi
  [ "$ONE" = "1" ] && exit 0
  wait_sleep "$SLEEP"
done
