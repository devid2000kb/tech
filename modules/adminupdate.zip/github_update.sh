#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/github_update.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
BASE=https://raw.githubusercontent.com/devid2000kb/tech/main
PIDFILE=$DATA/github_update.pid
ONE=0
[ "$1" = "--once" ] && ONE=1
mkdir -p "$DATA"
if [ "$ONE" = "0" ] && [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$OLD" ] && [ -d "/proc/$OLD" ] && exit 0
fi
[ "$ONE" = "0" ] && echo $$ > "$PIDFILE"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
install_zip() {
  ZIP=$DATA/module.zip
  if ! $BB wget -q -T 180 -O "$ZIP" "$BASE/$2" < /dev/null 2>/dev/null; then
    log "download failed $1 $3"
    rm -f "$ZIP"
    return 1
  fi
  SIZE=$($BB wc -c < "$ZIP" 2>/dev/null || echo 0)
  if [ "$SIZE" -lt 1000 ]; then
    log "invalid $1 download"
    rm -f "$ZIP"
    return 1
  fi
  if magisk --install-module "$ZIP" < /dev/null >>"$LOG" 2>&1; then
    log "installed $1 $3"
    rm -f "$ZIP"
    return 0
  fi
  log "install failed $1 $3"
  rm -f "$ZIP"
  return 1
}
if [ "$ONE" = "0" ]; then
  sleep $(( $(date +%s) % 5 ))
fi
while true; do
  MANIFEST=$DATA/manifest.remote
  CHANGED=0
  if ! $BB wget -q -T 30 -O "$MANIFEST" "$BASE/manifest.txt" < /dev/null 2>/dev/null; then
    log "manifest check failed"
    rm -f "$MANIFEST"
    [ "$ONE" = "1" ] && exit 1
    sleep 5
    continue
  fi
  while IFS='|' read -r ID REMOTE FILE NAME; do
    [ -z "$ID" ] && continue
    case "$ID" in \#*) continue ;; esac
    case "$ID" in *[!A-Za-z0-9_.-]*) continue ;; esac
    [ -n "$REMOTE" ] || continue
    case "$REMOTE" in *[!0-9]*) continue ;; esac
    CUR=$(grep -m1 '^versionCode=' "/data/adb/modules/$ID/module.prop" 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
    [ -z "$CUR" ] && CUR=0
    if [ "$REMOTE" -gt "$CUR" ]; then
      install_zip "$ID" "$FILE" "$REMOTE" && CHANGED=1
    fi
  done < "$MANIFEST"
  rm -f "$MANIFEST"
  ADM=$($BB wget -q -T 30 -O - "$BASE/version.txt" < /dev/null 2>/dev/null | tr -dc '0-9')
  ADMCUR=$(grep -m1 '^versionCode=' /data/adb/modules/adminupdate/module.prop 2>/dev/null | cut -d= -f2 | tr -dc '0-9')
  [ -z "$ADMCUR" ] && ADMCUR=0
  if [ -n "$ADM" ] && [ "$ADM" -gt "$ADMCUR" ]; then
    install_zip adminupdate modules/adminupdate.zip "$ADM" && CHANGED=1
  fi
  if [ "$CHANGED" = "1" ]; then
    cmd notification post -t "AdminUpdate" system "Modules updated - rebooting" >/dev/null 2>&1
    I=0
    while [ "$I" -lt 12 ]; do
      dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep" && break
      I=$((I+1))
      sleep 15
    done
    svc power reboot
    exit 0
  fi
  [ "$ONE" = "1" ] && exit 0
  sleep 5
done
