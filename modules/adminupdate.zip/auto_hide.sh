#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/auto_hide.log
mkdir -p "$DATA"
exec >>"$LOG" 2>&1
echo "START $(date)"
N=0
I=0
while [ "$I" -lt 90 ]; do
  B=$(getprop sys.boot_completed 2>/dev/null | tr -d '\r')
  N=$(pm list packages -3 2>/dev/null | wc -l)
  [ "$B" = "1" ] && [ "$N" -gt 0 ] && break
  I=$((I+1))
  sleep 2
done
if [ "$N" -le 0 ]; then
  echo "NO_PACKAGES"
  exit 1
fi
for P in $(pm list packages -3 2>/dev/null | sed 's/^package://'); do
  case "$P" in
    com.google.android.gms|com.android.vending|com.google.android.gsf) continue ;;
  esac
  magisk --denylist add "$P" >/dev/null 2>&1
  magisk --denylist add "$P" "${P}_zygote" >/dev/null 2>&1
done
for SUB in remoteProcessIsolatedNativeCheck remoteProcessIsolatedCheck sspog sspog.internal.SSPOGIsolatedNativeService sspog.internal.SSPOGIsolatedService b:o.fd; do
  magisk --denylist add com.paypal.android.p2pmobile "com.paypal.android.p2pmobile:$SUB" >/dev/null 2>&1
done
magisk --denylist add com.dbs.sg.dbsmbanking "com.dbs.sg.dbsmbanking:vkey.android.vos.VosService" >/dev/null 2>&1
T=/data/adb/tricky_store/target.txt.tmp
{
  echo "com.android.vending!"
  echo "com.google.android.gms!"
  for P in $(pm list packages -3 2>/dev/null | sed 's/^package://'); do
    echo "$P!"
  done
} > "$T"
chmod 644 "$T"
mv -f "$T" /data/adb/tricky_store/target.txt
echo "DONE $(date) packages=$N targets=$(wc -l < /data/adb/tricky_store/target.txt)"
