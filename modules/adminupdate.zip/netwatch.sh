#!/system/bin/sh
DATA=/data/adb/adminupdate
LOG=$DATA/net.log
mkdir -p "$DATA"
LAST=1
while true; do
  if dumpsys connectivity 2>/dev/null | grep -m1 'Active default network' | grep -q 'none'; then
    CUR=0
  else
    CUR=1
  fi
  if [ "$CUR" = "1" ] && [ "$LAST" = "0" ]; then
    touch "$DATA/netup"
    echo "$(date '+%F %T') online" >> "$LOG"
  fi
  LAST=$CUR
  sleep 10
done
